// this file must be UTF-8 encoded!!
{
/* begin number format */
NUMBER_FORMAT_NEG_MONEY_LABEL: "₣ 1,234; -₣ 1,234",
NUMBER_FORMAT_PAREN_MONEY_LABEL: "₣ 1,234; (₣ 1,234)",
NUMBER_FORMAT_NEG_DECIMAL_MONEY_LABEL: "₣ 1,234.56; -₣ 1,234.56",
NUMBER_FORMAT_NEG_MONEY: "₣ #,###;-₣ #,###",
NUMBER_FORMAT_PAREN_MONEY: "₣ #,###;(₣ #,###)",
NUMBER_FORMAT_NEG_DECIMAL_MONEY: "₣ #,###.##;-₣ #,###.##",
/* end number format */
}